import java.io.*;
import java.util.*;
public class ZodiacProject
{

	public static void main(String[] args) throws IOException
	{
		boolean keepGoing = true;
			printHeader();
			choosePath();
			while (keepGoing == true)
			{
				int numOfBirthdays = getBirthdays();
				if (numOfBirthdays < 1)
				{
					keepGoing = endProgram();
				}
				else
				{
					int [] [] birthdays = new int [3] [numOfBirthdays];
					birthdays = enterBirthdays(numOfBirthdays);
					String[][] info = checkAll(birthdays, numOfBirthdays);
					printResult(birthdays, info, numOfBirthdays);
					keepGoing = keepGoing(numOfBirthdays);
				}
			}
	}
	public static void printHeader() throws IOException
	{
		System.out.println("This program will ask you to input a birthday or a series of birthdays.");
		System.out.println("It will then provide you with the following information about that birthday (or those birthdays):");
		System.out.println("\n1. Western Zodiac\n2. Chinese Zodiac\n3. Birthstone\n4. Leap Year Status");
	}
	public static void choosePath () throws IOException
	{
		System.out.println("\nWould you like to know information about any of these, or do you want get straight to entering the birthday(s)?");
		System.out.println("Enter 'Info' for more information. Otherwise, enter 'Proceed':");
		Scanner in = new Scanner(System.in);
		String response = in.next();
		switch (response.charAt(0))
		{
			case 'I':
			case 'i':
			{
				printInfo();
				break;
			}
			case 'P':
			case 'p':
			{
				break;
			}
			default:
			{
				System.out.println("I'm sorry, but I don't know what you're asking me to do. Maybe you spelled it wrong?");
				System.out.println("Please try to enter it again.");
				choosePath();
				break;
			}
		}
	}
	public static int getBirthdays() throws IOException
	{
		System.out.println("\nHow many birthdays do you want to check?"
				+ "\nEnter the number as an integer (whole number):");
		Scanner in = new Scanner(System.in);
		int numOfBirthdays = in.nextInt();
		if (numOfBirthdays < 1)
		{
			System.out.println("You entered '0' as the number of birthdays you wanted to check. I can't check 0 birthdays."
					+ "\nDid you enter it wrong, or do you just want to exit?\nEnter the number of birthdays you want to check. Or, enter '0' to exit the program.");
			numOfBirthdays = in.nextInt();
			if (numOfBirthdays < 1)
			{
				System.out.println("Alright, I guess you're done then! I hope you enjoyed what you got out of the program!");
			}
		}
		return numOfBirthdays;
	}
	public static int [] [] enterBirthdays(int numOfBirthdays) throws IOException
	{
		System.out.println("\nIn order to organize this properly, the birthdays must be split into three parts: the birth month, date, and year."
				+ "\nPlease enter these inputs as numbers. When the birthdays are read back to you, the month will be changed into a word rather than a number,"
				+ "\nbut it needs to be entered as an integer for now.");
		System.out.println("Do you want a numbered list of the months in order to ensure you're entering the correct one? (Y/N)");
		Scanner in = new Scanner(System.in);
		String answer = in.next();
		switch (answer.charAt(0))
		{
			case 'y':
			case 'Y':
			{
				System.out.println("\nHere is a numbered list of the months of the year:");
				BufferedReader inFile = new BufferedReader(new FileReader("info.txt"));
				int count;
				String info;
				for (count = 1; count < 101; count++)
				{
					if (count < 89)
						inFile.readLine();
					else
					{
						info = inFile.readLine();
						System.out.println(info);
					}
				}
				break;
			}
			case 'n':
			case 'N':
			{
				System.out.println("Alright, I'll move on then.");
				break;
			}
			default:
			{
				System.out.println("Your input didn't match any of the options I gave you. Please try to enter it again.");
				enterBirthdays(numOfBirthdays);
				break;
			}
		}
		int count;
		int arrayCount = 0;
		int [] [] birthdays = new int [3] [numOfBirthdays];
		for (count = 0; count < numOfBirthdays; count++)
		{
			System.out.println("\nPlease enter the month of birthday #" +(count+1) + " (as an integer, please):");
			birthdays [arrayCount] [count] = in.nextInt();
			while (birthdays[arrayCount][count] > 12)
			{
				System.out.println("There are only 12 months in a year; you must have entered this wrong. \nPlease try to enter it again.");
				birthdays[arrayCount][count] = in.nextInt();
			}
			System.out.println("\nPlease enter the date of birthday #" +(count+1) + " (as an integer, like before):");
			birthdays [arrayCount+1] [count] = in.nextInt();
			while (birthdays [arrayCount+1] [count] > 31)
			{
				System.out.println("The maximum number of days in a month is 31 days; you must have entered this wrong. \nPlease try to enter it again.");
				birthdays[arrayCount+1][count] = in.nextInt();
			}
			System.out.println("\nPlease enter the year of birthday #" +(count+1) + " (as an integer, one more time):");
			birthdays [arrayCount+2] [count] = in.nextInt();
			while (birthdays [arrayCount+2] [count] < 1)
			{
				System.out.println("I'm sorry, but I can't calculate a lot of the required information if the year is earlier than the year 1 AD. \nPlease enter a year from 1 AD onward.");
				birthdays [arrayCount+2] [count] = in.nextInt();
			}
			birthdays = checkingDatesForAccuracy(birthdays, count);
			String month = convertToWords(birthdays, arrayCount, count);
			birthdays = checkEnteredBirthday(birthdays, count, arrayCount, month);
		}
		return birthdays;
	}
	public static String convertToWords(int [][] birthdays, int arrayCount, int count) throws IOException
	{
		String [] months = {"", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		String month = months[birthdays[arrayCount][count]];
		return month;
	}
	public static int [] [] checkEnteredBirthday(int [] [] birthdays, int count, int arrayCount, String month) throws IOException
	{
		month = convertToWords(birthdays, arrayCount, count);
		System.out.println("\nI will now give you the opportunity to change your input in case you mistyped something. This will continue to loop until you decide that the date entered is correct,"
				+ "\nso change it as many times as you deem necessary."
				+ "\n\nThe birthday you entered was: " + month + " " + birthdays[arrayCount+1] [count] + ", "
				+ birthdays[arrayCount+2][count] + ".");
		System.out.println("Is that correct?"
				+ "\nEnter 'Yes' if it is right. Enter 'No' if it is not.");
		Scanner in = new Scanner(System.in);
		String answer = in.next();
		if (answer.charAt(0) == 'y' || answer.charAt(0) == 'Y')
		{
			return birthdays;
		}
		else if (answer.charAt(0) == 'n' || answer.charAt(0) == 'N')
		{
			System.out.println("Which part of it is wrong? Answer with the name of the incorrect input (month, date, year):");
			answer = in.next();
			switch (answer.charAt(0))
			{
				case 'm':
				case 'M':
				{
					System.out.println("Okay, you input the wrong month. Enter the correct month now (as an integer, please):");
					birthdays[arrayCount] [count] = in.nextInt();
					while (birthdays[arrayCount][count] > 12)
					{
						System.out.println("There are only 12 months in a year; you must have entered this wrong. \nPlease try to enter it again.");
						birthdays[arrayCount][count] = in.nextInt();
					}
					break;
				}
				case 'd':
				case 'D':
				{
					System.out.println("Okay, you input the wrong date. Enter the correct date now (as an integer, please):");
					birthdays[arrayCount+1] [count] = in.nextInt();
					while (birthdays [arrayCount+1] [count] > 31)
					{
						System.out.println("The maximum number of days in a month is 31 days; you must have entered this wrong. \nPlease try to enter it again.");
						birthdays[arrayCount+1][count] = in.nextInt();
					}
					break;
				}
				case 'y':
				case 'Y':
				{
					System.out.println("Okay, you input the wrong year. Enter the correct year now (as an integer, please):");
					birthdays[arrayCount+2] [count] = in.nextInt();
					while (birthdays [arrayCount+2] [count] < 1)
					{
						System.out.println("I'm sorry, but I can't calculate a lot of the required information if the year is earlier than the year 1 AD. \nPlease enter a year from 1 AD onward.");
						birthdays [arrayCount+2] [count] = in.nextInt();
					}
					break;
				}
				default:
				{
					System.out.println("I'm sorry, I couldn't figure out what you wanted to change. Did you change your mind?"
							+ "\nI'm going to have you check it again.");
					break;
				}
			}
			birthdays = checkingDatesForAccuracy(birthdays, count);
			checkEnteredBirthday(birthdays, count, arrayCount, month);
			return birthdays;
		}
		else
		{
			System.out.println("I'm sorry, I don't understand your input. Please enter it again.");
			checkEnteredBirthday(birthdays, count, arrayCount, month);
			return birthdays;
		}
	}
	public static int [] [] checkingDatesForAccuracy(int[][] birthdays, int count) throws IOException
	{
		Scanner in = new Scanner(System.in);
		switch (birthdays[0][count])
		{
			case 2:
			{
				String leapYear = checkLeapYear(birthdays, count);
				while (birthdays[1][count] > 29)
				{
					System.out.println("The date you entered is invalid for the month of February, which has a maximum of 29 days.");
					System.out.println("Please enter it again.");
					birthdays[1][count] = in.nextInt();
				}
				while (leapYear.equals("is not a leap year.") && birthdays[1][count] > 28)
				{
					System.out.println("The date you entered does not exist for the year you entered (as that year is not a leap year)."
							+ "\nPlease enter a date between 1 and 28.");
					birthdays[1][count] = in.nextInt();
				}
				break;
			}
			case 4:
			case 6:
			case 9:
			case 11:
			{
				while (birthdays[1][count] > 30)
				{
					System.out.println("The date you entered is invalid for the month you entered, which has a maximum of 30 days.");
					System.out.println("Please enter a date between 1 and 30.");
					birthdays[1][count] = in.nextInt();
				}
				break;
			}
			default:
			{
				break;
			}
		}
		return birthdays;
	}
	public static String[][] checkAll(int[][] birthdays, int numOfBirthdays) throws IOException
	{
		String [][] info = new String[5][numOfBirthdays];
		int count = 0;
		for (count = 0; count < numOfBirthdays; count++)
		{
			info[0][count] = checkWestZodiac(birthdays, count);
			info[1][count] = checkChineseZodiac(birthdays, count);
			info[2][count] = checkMonthBirthstone(birthdays, count);
			info[3][count] = checkZodiacBirthstone(birthdays, info, count);
			info[4][count] = checkLeapYear(birthdays, count);
		}
		return info;
	}
	public static String checkWestZodiac (int[][]birthdays, int count) throws IOException
	{
		String zodiac;
		switch (birthdays[0][count])
		{
			case 1:
			{
				if (birthdays[1][count] < 20)
				{
					zodiac = "Capricorn";
				}
				else
				{
					zodiac = "Aquarius";
				}
				break;
			}
			case 2:
			{
				if (birthdays[1][count] < 19)
				{
					zodiac = "Aquarius";
				}
				else
				{
					zodiac = "Pisces";
				}
				break;
			}
			case 3:
			{
				if (birthdays[1][count] < 21)
				{
					zodiac = "Pisces";
				}
				else
				{
					zodiac = "Aries";
				}
				break;
			}
			case 4:
			{
				if (birthdays[1][count] < 20)
				{
					zodiac = "Aries";
				}
				else
				{
					zodiac = "Taurus";
				}
				break;
			}
			case 5:
			{
				if (birthdays[1][count] < 21)
				{
					zodiac = "Taurus";
				}
				else
				{
					zodiac = "Gemini";
				}
				break;
			}
			case 6:
			{
				if (birthdays[1][count] < 22)
				{
					zodiac = "Gemini";
				}
				else
				{
					zodiac = "Cancer";
				}
				break;
			}
			case 7:
			{
				if (birthdays[1][count] < 23)
				{
					zodiac = "Cancer";
				}
				else
				{
					zodiac = "Leo";
				}
				break;
			}
			case 8:
			{
				if (birthdays[1][count] < 23)
				{
					zodiac = "Leo";
				}
				else
				{
					zodiac = "Virgo";
				}
				break;
			}
			case 9:
			{
				if (birthdays[1][count] < 23)
				{
					zodiac = "Virgo";
				}
				else
				{
					zodiac = "Libra";
				}
				break;
			}
			case 10:
			{
				if (birthdays[1][count] < 24)
				{
					zodiac = "Libra";
				}
				else
				{
					zodiac = "Scorpio";
				}
				break;
			}
			case 11:
			{
				if (birthdays[1][count] < 23)
				{
					zodiac = "Scorpio";
				}
				else
				{
					zodiac = "Sagittarius";
				}
				break;
			}
			case 12:
			{
				if (birthdays[1][count] < 22)
				{
					zodiac = "Sagittarius";
				}
				else
				{
					zodiac = "Capricorn";
				}
				break;
			}
			default:
			{
				zodiac = "Error";
				break;
			}
		}
		return zodiac;
	}
	public static String checkChineseZodiac(int[][]birthdays, int count) throws IOException
	{
		String cnZodiac;
		int quotient = birthdays[2][count]%12;
		switch (quotient)
		{
			case 0:
			{
				cnZodiac = "Monkey";
				break;
			}
			case 1:
			{
				cnZodiac = "Rooster";
				break;
			}
			case 2:
			{
				cnZodiac = "Dog";
				break;
			}
			case 3:
			{
				cnZodiac = "Pig";
				break;
			}
			case 4:
			{
				cnZodiac = "Rat";
				break;
			}
			case 5:
			{
				cnZodiac = "Ox";
				break;
			}
			case 6:
			{
				cnZodiac = "Tiger";
				break;
			}
			case 7:
			{
				cnZodiac = "Rabbit";
				break;
			}
			case 8:
			{
				cnZodiac = "Dragon";
				break;
			}
			case 9:
			{
				cnZodiac = "Snake";
				break;
			}
			case 10:
			{
				cnZodiac = "Horse";
				break;
			}
			case 11:
			{
				cnZodiac = "Sheep";
				break;
			}
			default:
			{
				System.out.println("Something went wrong.");
				cnZodiac = "Invalid"; // maybe add more?
				break;
			}
		}
		return cnZodiac;
	}
	public static String checkMonthBirthstone(int[][]birthdays, int count) throws IOException
	{
		String monthBirthstone;
		switch (birthdays[0][count])
		{
			case 1:
			{
				monthBirthstone = "Garnet (both modern and traditional).";
				break;
			}
			case 2:
			{
				monthBirthstone = "Amethyst (both modern and traditional).";
				break;
			}
			case 3:
			{
				monthBirthstone = "Aquamarine (modern) and Bloodstone (traditional).";
				break;
			}
			case 4:
			{
				monthBirthstone = "Diamond (both modern and traditional).";
				break;
			}
			case 5:
			{
				monthBirthstone = "Emerald (both modern and traditional).";
				break;
			}
			case 6:
			{
				monthBirthstone = "Alexandrite (modern) and Pearl (traditional).";
				break;
			}
			case 7:
			{
				monthBirthstone = "Ruby (both modern and traditional).";
				break;
			}
			case 8:
			{
				monthBirthstone = "Peridot and Spinel (modern) and Sardonyx (traditional).";
				break;
			}
			case 9:
			{
				monthBirthstone = "Sapphire (both modern and traditional).";
				break;
			}
			case 10:
			{
				monthBirthstone = "Tourmaline (modern) and Opal (traditional).";
				break;
			}
			case 11:
			{
				monthBirthstone = "Golden Topaz and Citrine (modern) and Topaz (traditional).";
				break;
			}
			case 12:
			{
				monthBirthstone = "Blue Zircon, Blue Topaz, and Tanzanite (modern) as well as Turquoise and Lapis (traditional)";
				break;
			}
			default:
			{
				monthBirthstone = "Error";
				break;
			}
		}
		return monthBirthstone;
	}
	public static String checkZodiacBirthstone(int[][]birthdays, String[][]info, int count) throws IOException
	{
		String zodiacBirthstone;
		switch (info[0][count])
		{
			case "Aries":
			{
				zodiacBirthstone = "Bloodstone";
				break;
			}
			case "Aquarius":
			{
				zodiacBirthstone = "Garnet";
				break;
			}
			case "Cancer":
			{
				zodiacBirthstone = "Emerald";
				break;
			}
			case "Capricorn":
			{
				zodiacBirthstone = "Ruby";
				break;
			}
			case "Gemini":
			{
				zodiacBirthstone = "Agate";
				break;
			}
			case "Leo":
			{
				zodiacBirthstone = "Onyx";
				break;
			}
			case "Libra":
			{
				zodiacBirthstone = "Chrysolite";
				break;
			}
			case "Pisces":
			{
				zodiacBirthstone = "Amethyst";
				break;
			}
			case "Sagittarius":
			{
				zodiacBirthstone = "Topaz";
				break;
			}
			case "Scorpio":
			{
				zodiacBirthstone = "Beryl";
				break;
			}
			case "Taurus":
			{
				zodiacBirthstone = "Sapphire";
				break;
			}
			case "Virgo":
			{
				zodiacBirthstone = "Carnelian";
				break;
			}
			default:
			{
				zodiacBirthstone = "Error";
			}
		}
		return zodiacBirthstone;
	}
	public static String checkLeapYear(int [] [] birthdays, int count) throws IOException
	{
		String status;
		int quotient = birthdays[2][count]%4;
		if (quotient == 0)
		{
			if (birthdays[2][count]%100 != 0)
			{
				status = "is a leap year.";
			}
			else
			{
				if (birthdays[2][count]%400 == 0)
				{
					status = "is a leap year.";
				}
				else
				{
					status = "is not a leap year.";
				}
			}
		}
		else
		{
			status = "is not a leap year.";
		}
		return status;
	}
	public static void printResult(int[][]birthdays, String[][]info, int numOfBirthdays) throws IOException
	{
		if (numOfBirthdays > 1)
		{
			System.out.println("\nI have finished organizing all of the information about the birthdays you entered. I will print it now.");
		}
		else
		{
			System.out.println("\nI have finished organizing all of the information about the birthday you entered. I will print it now.");
		}
		int arrayCount = 0;
		int count;
		for (count = 0; count < numOfBirthdays; count++)
		{
			System.out.print("\nBirthday #" + (count+1)+ ":\t");
			String month = convertToWords(birthdays, arrayCount, count);
			System.out.println(month + " " + birthdays[1][count] + ", " + birthdays[2][count]);
			System.out.println("\nThe Western Zodiac of this birthday is " + info[0][count] + ". It's corresponding zodiac birthstone is " + info[3][count] + ".");
			if (month.equals("March") || month.equals("June") || month.equals("August") || month.equals("October") || month.equals("November") || month.equals("December"))
			{
				System.out.println("The birthstones for this birthday's birth month, " + month + ", are " + info[2][count]);
			}
			else
			{
				System.out.println("The birthstone for this birthday's birth month, " + month + ", is " + info[2][count]);
			}
			System.out.println("The Chinese Zodiac of this birthday is the year of the " + info[1][count] + ".");
			System.out.println("Finally, the year of this birthday, " + birthdays[2][count] + ", " + info[4][count]);
			if (birthdays[2][count] < 1582)
			{
				System.out.println("Leap years as we know them now were not implemented until 1582 -- when the Gregorian calendar became the most common calendar worldwide."
				+ "\nHowever, rather than disregarding the leap year status due to this discrepancy in history, I chose to print it as if leap years always existed the way we know them.");
			}
		}
	}
	public static void printInfo() throws IOException
	{
		System.out.println("\nYou have chosen to get more information. What would you like to get information for?");
		System.out.println("Please enter the number assigned to the topic you want more information about."
				+ "\nEnter '5' to get information on all four. Enter '0' to return to entering birthdays.");
		System.out.println("\n1. Western Zodiac \n2. Chinese Zodiac \n3. Birthstone \n4. Leap Years");
		Scanner in = new Scanner(System.in);
		int response = in.nextInt();
		switch (response)
		{
			case 1:
			{
				westZodiacInfo();
				moreInfo();
				break;
			}
			case 2:
			{
				chineseZodiacInfo();
				moreInfo();
				break;
			}
			case 3:
			{
				birthstoneInfo();
				moreInfo();
				break;
			}
			case 4:
			{
				leapYearInfo();
				moreInfo();
				break;
			}
			case 5:
			{
				System.out.println("\nIn order to make this more easy to read, I'm going to split the information into sections."
						+ "\nI will prompt you to enter a number to continue to the next section."
						+ "\nEnter '1' to continue.");
				Scanner input = new Scanner(System.in);
				int newInput = input.nextInt();
				while (newInput != 1)
				{
					System.out.println("You didn't enter the option I gave you. You cannot proceed until you enter '1'.\nPlease try to enter it again.");
					newInput = input.nextInt();
				}
				if (newInput == 1)
				{
					westZodiacInfo();
					System.out.println("Enter '1' to continue.");
					newInput = input.nextInt();
					while (newInput != 1)
					{
						System.out.println("You didn't enter the option I gave you. You cannot proceed until you enter '1'.\nPlease try to enter it again.");
						newInput = input.nextInt();
					}
					if (newInput == 1)
					{
						chineseZodiacInfo();
						System.out.println("Enter '1' to continue.");
						newInput = input.nextInt();
						while (newInput != 1)
						{
							System.out.println("You didn't enter the option I gave you. You cannot proceed until you enter '1'.\nPlease try to enter it again.");
							newInput = input.nextInt();
						}
						if (newInput == 1)
						{
							birthstoneInfo();
							System.out.println("Enter '1' to continue.");
							newInput = input.nextInt();
							while (newInput != 1)
							{
								System.out.println("You didn't enter the option I gave you. You cannot proceed until you enter '1'.\nPlease try to enter it again.");
								newInput = input.nextInt();
							}
							if (newInput == 1)
							{
								leapYearInfo();
								System.out.println("This is all of the information. Now, I'll send you to the birthday menu.");
							}
						}
					}
				}
				break;
			}
			case 0:
			{
				System.out.println("Okay, I'll send you to the input menu.");
				break;
			}
			default:
			{
				System.out.println("I'm sorry, but I don't understand your input. Did you spell it wrong?"
						+ "\nPlease try to enter it again.");
				choosePath();
				break;
			}
		}
	}
	public static void westZodiacInfo() throws IOException
	{
		BufferedReader inFile = new BufferedReader(new FileReader("info.txt"));
		int count = 1;
		for (count = 1; count < 22; count++)
		{
			String info = inFile.readLine();
			System.out.println(info);
		}
	}
	public static void chineseZodiacInfo() throws IOException
	{
		BufferedReader inFile = new BufferedReader(new FileReader("info.txt"));
		int count;
		String info;
		for (count = 1; count < 46; count++)
		{
			if (count < 22)
				inFile.readLine();
			else
			{
				info = inFile.readLine();
				System.out.println(info);
			}
		}
	}
	public static void birthstoneInfo() throws IOException
	{
		BufferedReader inFile = new BufferedReader(new FileReader("info.txt"));
		int count;
		String info;
		for (count = 1; count < 84; count++)
		{
			if (count < 46)
				inFile.readLine();
			else
			{
				info = inFile.readLine();
				System.out.println(info);
			}
		}
	}
	public static void leapYearInfo() throws IOException
	{
		BufferedReader inFile = new BufferedReader(new FileReader("info.txt"));
		int count;
		String info;
		for (count = 1; count < 89; count++)
		{
			if (count < 84)
				inFile.readLine();
			else
			{
				info = inFile.readLine();
				System.out.println(info);
			}
		}
	}
	public static void moreInfo() throws IOException
	{
		System.out.println("Would you like more information, or do you want to start entering birthdays?"
				+ "\nEnter 'Info' to get more information. Enter 'Proceed' to start entering birthdays.");
		Scanner in = new Scanner(System.in);
		String input = in.next();
		switch (input.charAt(0))
		{
			case 'I':
			case 'i':
			{
				printInfo();
				break;
			}
			case 'P':
			case 'p':
			{
				break;
			}
			default:
			{
				System.out.println("Your input did not match any of the options I gave you. Please try to enter it again.");
				moreInfo();
				break;
			}
		}
	}
	public static boolean keepGoing (int numOfBirthdays) throws IOException
	{
		if (numOfBirthdays == 1)
		{
			System.out.println("\nI have printed all of the information for the birthday you entered.");
		}
		else
		{
			System.out.println("\nI have printed all of the information for the birthdays you entered.");
		}
		System.out.println("\nWould you like to enter more birthdays?\nEnter 'Yes' to keep going. Enter 'No' or 'End' to end the program.");
		Scanner in = new Scanner(System.in);
		String answer = in.next();
		boolean keepGoing;
		switch (answer.charAt(0))
		{
			case 'Y':
			case 'y':
			{
				keepGoing = true;
				break;
			}
			case 'N':
			case 'n':
			case 'E':
			case 'e':
			{
				System.out.println("That's it, then! Thanks for using my program, and I hope you enjoyed the results!");
				keepGoing = false;
				break;
			}
			default:
			{
				System.out.println("It isn't clear to me whether you want to stop or not. Did you misspell your answer?");
				System.out.println("Please try to enter it again.");
				keepGoing = true;
				keepGoing(numOfBirthdays);
				break;
			}
		}
		return keepGoing;
	}
	public static boolean endProgram () throws IOException
	{
		boolean keepGoing = false;
		return keepGoing;
	}
}